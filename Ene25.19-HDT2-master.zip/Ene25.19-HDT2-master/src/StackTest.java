import org.junit.Test;

import java.util.NoSuchElementException;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.*;

public class StackTest {

    @Test
    public void TestNewStack() {
        // Crear una nueva stack
        Stack<Integer> s = new VectorStack<>();
        // ! La nueva stack debería estar vacía
        assertTrue(s.empty());
    }

    @Test
    public void TestPushPeekPop() {
        // Crear una nueva stack
        Stack<String> s = new VectorStack<>();
        String objeto1 = "Objeto 1";
        // Poner un objeto en la pila
        s.push(objeto1);
        // Hacer la operación peek
        // ! Debería devolver el mismo objeto
        assertEquals(objeto1, s.peek());
        // ! Debería de estar no vacía
        assertFalse(s.empty());
        // Hacer la operación pop
        // ! Debería devolver el mismo objeto
        assertEquals(objeto1, s.pop());
        // ! Debería de estar no vacía
        assertTrue(s.empty());
    }

    @Test
    public void TestSize() {
        // Crear una nueva stack
        Stack<Integer> s = new VectorStack<>();
        Integer objeto1 = 1;
        Integer objeto2 = 2;
        // Poner un objeto en la pila
        s.push(objeto1);
        // Poner un objeto en la pila
        s.push(objeto2);
        // ! size debería ser 2
        assertEquals(2, s.size());
    }

    @Test
    public void TestPopPeek() {
        // Crear una nueva stack
        Stack<Integer> s = new VectorStack<>();
        Integer objeto1 = 1;
        Integer objeto2 = 2;
        Integer objeto3 = 3;
        Integer objeto4 = 4;
        // Poner un objeto en la pila
        s.push(objeto1);
        // Poner un objeto en la pila
        s.push(objeto2);
        // Poner un objeto en la pila
        s.push(objeto3);
        // Poner un objeto en la pila
        s.push(objeto4);
        // Poner un objeto en la pila
        s.push(objeto4);
        // Poner un objeto en la pila
        s.push(objeto3);
        // Poner un objeto en la pila
        s.push(objeto2);
        // Poner un objeto en la pila
        s.push(objeto1);

        // ! Debería devolver el objeto 1
        assertEquals(objeto1, s.peek());
        // ! Debería devolver el objeto 1
        assertEquals(objeto1, s.pop());
        // ! Debería devolver el objeto 2
        assertEquals(objeto2, s.peek());
        // ! Debería devolver el objeto 2
        assertEquals(objeto2, s.pop());
        // ! Debería devolver el objeto 3
        assertEquals(objeto3, s.peek());
        // ! Debería devolver el objeto 3
        assertEquals(objeto3, s.pop());
        // ! Debería devolver el objeto 4
        assertEquals(objeto4, s.peek());
        // ! Debería devolver el objeto 4
        assertEquals(objeto4, s.pop());
        // ! Debería devolver el objeto 4
        assertEquals(objeto4, s.peek());
        // ! Debería devolver el objeto 4
        assertEquals(objeto4, s.pop());
        // ! Debería devolver el objeto 3
        assertEquals(objeto3, s.peek());
        // ! Debería devolver el objeto 3
        assertEquals(objeto3, s.pop());
        // ! Debería devolver el objeto 2
        assertEquals(objeto2, s.peek());
        // ! Debería devolver el objeto 2
        assertEquals(objeto2, s.pop());
        // ! Debería devolver el objeto 1
        assertEquals(objeto1, s.peek());
        // ! Debería devolver el objeto 1
        assertEquals(objeto1, s.pop());
        // ! Debería estar vacía
        assertTrue(s.empty());
    }

    @Test
    public void TestPeekPopEmpty() {
        // Crear una nueva stack
        Stack<Double> s = new VectorStack<>();
        // ! La nueva stack debería estar vacía
        assertTrue(s.empty());
        // Realizar peek con la pila vacía
        try {
            s.peek();
            fail();
        } catch (Exception e) {
            // ! Debería lanzar NoSuchElementException
            assertThat(e, instanceOf(NoSuchElementException.class));
        }
        // Realizar pop con la pila vacía
        try {
            s.pop();
            fail();
        } catch (Exception e) {
            // ! Debería lanzar NoSuchElementException
            assertThat(e, instanceOf(NoSuchElementException.class));
        }
    }
}
