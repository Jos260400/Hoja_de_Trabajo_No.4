import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class iCalculadoraTest {
    private static double MINIMUM_STEP = 1.00;
    private static double EPSILON = MINIMUM_STEP * 0.01; // 1%

    private static boolean almostEqual(double a, double b, double eps) {
        // Esta función es un pequeño ayudante: sirve para comparar valores decimales. Es necesaria porque debido al
        // formato IEEE 754, a veces las representaciones no son totalmente exactas y es posible que bajo alguna
        // circunstancia aleatoria los comparadores simples (<, >, !=, == y sus combinaciones) fallen.
        //
        // Con un épsilon bien elegido, esta función garantiza el resultado.
        return ((b <= (a + eps)) && (b >= (a - eps)));
    }

    @Test
    public void TestSumar() {
        iCalculadora i = new Calculo();
        // La calculadora debe sumar
        assertTrue(almostEqual(2.00, i.sumar(1, 1), EPSILON));
    }

    @Test
    public void TestRestar() {
        iCalculadora i = new Calculo();
        // La calculadora debe restar
        assertTrue(almostEqual(1.00, i.restar(4, 3), EPSILON));
    }

    @Test
    public void TestMultiplicar() {
        iCalculadora i = new Calculo();
        // La calculadora debe multiplicar
        assertTrue(almostEqual(8.00, i.multiplicar(4, 2), EPSILON));
    }

    @Test
    public void TestDividir() {
        iCalculadora i = new Calculo();
        // La calculadora debe dividir
        assertTrue(almostEqual(2.00, i.dividir(4, 2), EPSILON));
    }
}